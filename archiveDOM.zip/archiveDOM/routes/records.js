const testFolder = '/Users/ctsuser1/Documents/CTS-Walgreens/session_Replay/rrweb-master/events';
var express = require('express');
var router = express.Router();
const fs = require('fs');

router.post('/', function(req, res, next) {
let events = [];
let rrwebevents = {};
  fs.readdirSync(testFolder).forEach(file => {  
    console.log(file);
    if(file !== '.DS_Store'){
      console.log('in');
      console.log(file);
      let filePath = testFolder + '/' + file;
      const data = fs.readFileSync(filePath, {encoding:'utf8'});
      //events.push(JSON.parse(data).events);
      JSON.parse(data).events.forEach(event => events.push(event));
    }
  });
  rrwebevents = {events}
  res.send(rrwebevents);
});

module.exports = router;
